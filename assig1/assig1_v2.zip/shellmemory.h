
int interpreter(char *words[]);

