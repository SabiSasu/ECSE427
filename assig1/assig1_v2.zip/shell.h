
int parse(char input[]);
